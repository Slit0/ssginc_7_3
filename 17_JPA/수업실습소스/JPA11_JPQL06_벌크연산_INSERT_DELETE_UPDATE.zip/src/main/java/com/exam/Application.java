package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		//1. 데이터 저장. native 메서드 사용
		String jpql ="""
					  insert into Member (id, name) values( 1001, '홍길동')
				     """;
		
		Query query = em.createNativeQuery(jpql); // JDBC의 PreparedStatement와 동일한 기능 
		int n = query.executeUpdate();
		log.info("LOGGER: 1. insert 갯수:{}", n);
		
		//2. 데이터 수정. 
		String jpql2 ="""
					  update Member as m
					  set m.name = ?1
					  where m.id = ?2
				     """;
		
		Query query2 = em.createQuery(jpql2); // JDBC의 PreparedStatement와 동일한 기능
		query2.setParameter(1, "이순신");
		query2.setParameter(2,1001);
		int n2 = query2.executeUpdate();
		log.info("LOGGER: 2. update 갯수:{}", n2);
		
		
		//3. 데이터 삭제. 
				String jpql3 ="""
							  delete from Member as m
							  where m.id = ?1
						     """;
				
			Query query3 = em.createQuery(jpql3); // JDBC의 PreparedStatement와 동일한 기능
			query3.setParameter(1,1001);
			int n3 = query3.executeUpdate();
			log.info("LOGGER: 3. delete 갯수:{}", n3);
		
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







