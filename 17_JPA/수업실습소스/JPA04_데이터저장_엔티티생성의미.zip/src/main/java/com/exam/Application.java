package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		//엔티티 생성
		// 비영속상태		
		Person p = Person.builder()
					     //.id(1000L)
					     .name("홍길동")
					     .age(20)
					     .build();
		
		Person p2 = Person.builder()
			     //.id(1000L)
			     //.name("홍길동")
			     .age(20)
			     .build();
		
		// 영속상태
		log.info("LOGGER: persist 전");
		em.persist(p);
		em.persist(p2);
		log.info("LOGGER: commit 전");
		
		//트랜잭션 종료
		tx.commit(); // insert 문 실행
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







