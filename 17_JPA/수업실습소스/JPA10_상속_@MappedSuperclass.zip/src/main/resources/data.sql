insert into teacher(id, name, email) values ( 20001, 'John', 'john@google.com');
insert into teacher(id, name, email) values ( 20002, 'Maria', 'Maria@google.com');
insert into teacher(id, name, email) values ( 20003, 'Jim', 'Jim@google.com');


insert into student(id, name, address) values ( 30001, 'hong', '서울 강남점');
insert into student(id, name, address) values ( 30002, 'park', '부산 센텀점');
insert into student(id, name, address) values ( 30003, 'lee', '제주 서귀포점');

commit; 