drop table if exists member;
create table member
	( id bigint primary key auto_increment,
	  name varchar(255)
	);