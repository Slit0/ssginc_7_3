package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Team;
import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
	   // N+1 문제 발생
		String jpql ="""
					  select m
					  from Member as m
					  JOIN m.team as t
				     """;
		TypedQuery<Member> query =
				em.createQuery(jpql, Member.class);
		
		List<Member> list = query.getResultList();
		for(Member m : list) {
			Team t = m.getTeam();
			log.info("1.  N+1 문제 발생:{}", t);
		}
		 // N+1 문제 해결
		String jpql2 ="""
					  select m
					  from Member as m
					  JOIN FETCH m.team as t
				     """;
		TypedQuery<Member> query2 =
				em.createQuery(jpql2, Member.class);
		
		List<Member> list2 = query.getResultList();
		for(Member m : list2) {
			Team t = m.getTeam();
			log.info("2.  N+1 문제 해결:{}", t);
		}
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







