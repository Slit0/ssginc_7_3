package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Team;
import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		// 서브쿼리
		// 이름이 4글자인 사원의 Team 출력하시오.
		// select m.team   from Member as m where length(m.username)=4
		String jpql = """
					  select t
					  from Team as t
					  where t IN ( select m.team   from Member as m where length(m.username)=4)
				      """;
		TypedQuery<Team> query =
				em.createQuery(jpql, Team.class);
		
		List<Team> list = query.getResultList();
		for(Team t : list) {
			log.info("1. 이름이 4글자인 사원의 Team 출력:{}", t);
		}
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







