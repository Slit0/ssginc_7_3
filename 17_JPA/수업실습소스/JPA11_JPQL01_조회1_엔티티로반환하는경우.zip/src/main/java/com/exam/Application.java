package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Todo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		//1. 전체조회
//		TypedQuery<Todo> query =
//				em.createQuery("select t from Todo as t", Todo.class);
//		List<Todo> todoList = query.getResultList();
		
		List<Todo> todoList = em.createQuery("select t from Todo as t", Todo.class)
				              .getResultList();
		log.info("LOGGER: 1. 전체조회:{}", todoList);
		
		//2. 조건지정1- 위치로 치환
		// 1.2.3. Parameters 참조
//		TypedQuery<Todo> query2 = em.createQuery("select t from Todo as t where t.id = ?1", Todo.class);
//		query2.setParameter(1, 10001L);
//		List<Todo> todoList2 = query2.getResultList();   // [Todo(id=10001] 리스트에 저장됨.


		List<Todo> todoList2 = em.createQuery("select t from Todo as t where t.id = ?1", Todo.class)
                              .setParameter(1, 10001L).getResultList();   // [Todo(id=10001] 리스트에 저장됨.
		log.info("LOGGER: 2. 조건조회(리스트로):{}", todoList2);
				
		Todo todo =  em.createQuery("select t from Todo as t where t.id = ?1", Todo.class)
                    .setParameter(1, 10001L).getSingleResult();            // Todo(id=10001
		log.info("LOGGER: 2. 조건조회(Todo):{}", todo);
		
		//2. 조건지정2- name로 치환
		List<Todo> todoList3 = em.createQuery("select t from Todo as t where t.id = :userid", Todo.class)
                .setParameter("userid", 10002L).getResultList();   // [Todo(id=10001] 리스트에 저장됨.
		log.info("LOGGER: 2. 조건조회2(리스트로):{}", todoList3);
			
		Todo todo2 =  em.createQuery("select t from Todo as t where t.id = :userid", Todo.class)
		      .setParameter("userid", 10002L).getSingleResult();            // Todo(id=10001
		log.info("LOGGER: 2. 조건조회2(Todo):{}", todo2);
		
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







