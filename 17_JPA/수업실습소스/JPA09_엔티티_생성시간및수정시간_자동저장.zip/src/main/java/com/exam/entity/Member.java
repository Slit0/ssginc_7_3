package com.exam.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Builder
@Entity
public class Member {

	@Id // pk 역할
	@GeneratedValue   // auto_increment 기능
	Long id;
	
	String name;
	
	@CreationTimestamp
	@Column(updatable = false)
	LocalDateTime createDate;  // 저장할 때만 자동저장하고 수정할때는 저장하면 안됨.

	@UpdateTimestamp
	@Column(insertable = false)
	LocalDateTime updateDate; // 저장할 때만 자동저장안하고 수정할때만 저장하면 됨.
	

}
