package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
	// Member 생성하는 작업
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작	
	try {

		Member m = Member.builder()
				   .name("홍길동")
				   .build();
		em.persist(m);
		
		//트랜잭션 종료
		tx.commit();   // insert문 실행
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}
	
	//시간차
	Thread.sleep(10000);  // 10초동안 멈춤 

	// Member 수정하는 작업
		tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작	
		try {

			Member findMember = em.find(Member.class, 1L);
			findMember.setName("이순신2"); 
			
			//트랜잭션 종료
		tx.commit();   
			
		}catch(Exception e) {
			e.printStackTrace();
			tx.rollback();		
		}finally {
			em.close();
		}
		
	}//end run
}//end class







