package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Locker;
import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		// INNER 조인
		//1. 명시적 조인
		String jpql2="""
				 select m
				 from Member as m
				 JOIN Locker as x
				 ON m.locker = x   
				""";
		//2. 묵시적 조인
		String jpql="""
				 select m
				 from Member as m
				 JOIN m.locker as x
				""";
		TypedQuery<Member> query =
				em.createQuery(jpql, Member.class);
		
		List<Member> list = query.getResultList();
		log.info("LOGGER: 2. 묵시적 조인:{}", list);
		
		// OUTER 조인
		String jpql3="""
				 select m
				 from Member as m
				 LEFT OUTER JOIN m.locker as x
				""";
		String jpql4="""
				 select m
				 from Member as m
				 RIGHT OUTER JOIN m.locker as x
				""";
		TypedQuery<Member> query3 =
				em.createQuery(jpql4, Member.class);
		
		List<Member> list3 = query3.getResultList();
		log.info("LOGGER: 3. OUTER  조인:{}", list3);
		
		
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







