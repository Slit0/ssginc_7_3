package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Team;
import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Tuple;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		String jpql="""
					 select m.team as team, 
					       count(m) as cnt, 
					       max(m.id) as max, 
					       min(m.id) as min,
					       sum(m.id) as sum
					 from Member as m
					 group by m.team
				     having count(m) >= 2
				     """;
		   List<Tuple> tuples =
	                em.createQuery(jpql,Tuple.class)
	                    .getResultList();
	        for (Tuple tuple : tuples) {
	        	Team team = (Team)tuple.get("team", Team.class);
	        	Long cnt = tuple.get("cnt", Long.class);
	        	Long max = tuple.get("max", Long.class);
	        	Long min = tuple.get("min", Long.class);
	        	Long sum = tuple.get("sum", Long.class);
	           
	            log.info("LOGGER: 1. Team:{}, cnt:{}, max:{}, min:{}, sum:{}", team, cnt, max,min , sum);
	        }
		
		
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







