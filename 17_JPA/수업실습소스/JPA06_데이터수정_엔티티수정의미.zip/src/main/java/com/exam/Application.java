package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		//새로운 2명의 엔티티 작성
		//비영속상태
		Person p = Person.builder()
			     //.id(1000L)
			     .name("홍길동")
			     .age(20)
			     .build();

		Person p2 = Person.builder()
	     //.id(1000L)
	     .name("이순신")
	     .age(30)
	     .build();
		
		//영속상태
		em.persist(p);
		em.persist(p2);
		
		em.flush(); // insert 문 실행
		em.clear(); // Entity Context 비우기
		
		// 수정작업: 홍길동-> 유관순
		Person x = em.find(Person.class, 1L);  // 엔티티 컨텍스트에 없기 때문에  select문 실행
		x.setName("유관순");
		
		//지금상태는  엔티티 컨텍스트에는 유관순, DB에는 홍길동 즉 동기화 안된 상태.
	
		log.info("LOGGER: commit 전");
		
		//트랜잭션 종료
		tx.commit();  // 더티체킹(변경사항체크)때문에 update문이 실행됨. DB는 유관순으로 변경됨.
		// username만 변경했음에도 불구하고 update문을 보면 age까지 수정됨.
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







