insert into member(id, name) values (1000,'홍길동');
insert into member(id, name) values (1001,'이순신');
insert into member(id, name) values (1002,'유관순');
commit;