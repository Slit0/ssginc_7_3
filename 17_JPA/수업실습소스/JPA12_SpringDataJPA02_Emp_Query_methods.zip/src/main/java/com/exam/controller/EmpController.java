package com.exam.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.EmpDTO;
import com.exam.service.EmpService;

@RestController
public class EmpController {

	EmpService empService;
	
	public EmpController(EmpService empService) {
		this.empService = empService;
	}



	@GetMapping("/emps/{ename}")
	public ResponseEntity<List<EmpDTO>> findByEname(@PathVariable String ename){
		List<EmpDTO> empList = empService.findByEname(ename);
		return ResponseEntity.status(200).body(empList);
	}
	@GetMapping("/emps2/{ename}/{sal}")
	public ResponseEntity<List<EmpDTO>> findByEnameOrSal(@PathVariable String ename, @PathVariable Long sal){
		List<EmpDTO> empList = empService.findByEnameOrSal(ename, sal);
		return ResponseEntity.status(200).body(empList);
	}
	
	@GetMapping("/emps3/{sal}")
	public ResponseEntity<List<EmpDTO>> findBySalLessThan( @PathVariable Long sal){
		List<EmpDTO> empList = empService.findBySalLessThan( sal);
		return ResponseEntity.status(200).body(empList);
	}
	@GetMapping("/emps4/{ename}")
	public ResponseEntity<List<EmpDTO>> findByEnameContaining( @PathVariable String ename){
		List<EmpDTO> empList = empService.findByEnameContaining( ename);
		return ResponseEntity.status(200).body(empList);
	}
	@GetMapping("/emps5")
	public ResponseEntity<List<EmpDTO>> findByCommIsNull(){
		List<EmpDTO> empList = empService.findByCommIsNull();
		return ResponseEntity.status(200).body(empList);
	}
}








