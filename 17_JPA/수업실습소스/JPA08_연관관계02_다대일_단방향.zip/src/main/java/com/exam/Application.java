package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Team;
import com.exam.entity.Member;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		// Member 조회
		Member findMember = em.find(Member.class, 20001L);
		log.info("LOGGER: findMember:{}", findMember.getUsername());
		
		Team findTeam = findMember.getTeam();
		log.info("LOGGER: findTeam:{},{}", findTeam.getName(), findTeam.getLocation());
		
		
		/*
			 EAGER 경우
			 - Member를 find했음에도 불구하고 Locker 정보도 가져옴.
			  따라서 엔티티 컨텍스트에 Member와 Locker 모두 존재함.
			  결국 Locker 정보조회시 select문 실행안됨.
		
		     LAZY 경우
		     - Member만 가져옴.
			   결국 엔티티 컨텍스트에 Member만 존재함.
			   따라서 Locker 정보조회시 select문 실행됨.
		*/
		//트랜잭션 종료
		tx.commit();   
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







