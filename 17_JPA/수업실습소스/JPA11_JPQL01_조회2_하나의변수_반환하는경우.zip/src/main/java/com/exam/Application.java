package com.exam;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Todo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
	    // 엔티티에서 하나의 변수만 반환하는 경우
		TypedQuery<String> query =
				em.createQuery("select t.description from Todo as t", String.class);
        List<String> strList = query.getResultList();
        log.info("LOGGER: 1. description만 출력:{}", strList);
        
        
        TypedQuery<Long> query2 =
				em.createQuery("select t.id from Todo as t", Long.class);
        List<Long> longList = query2.getResultList();
        log.info("LOGGER: 2. id만 출력:{}", longList);
        
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







