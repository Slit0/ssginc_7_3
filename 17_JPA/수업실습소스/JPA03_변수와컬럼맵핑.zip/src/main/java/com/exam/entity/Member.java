package com.exam.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Builder
@Entity
public class Member {

	@Id // pk 역할
	@GeneratedValue   // auto_increment 기능
	Long id;
	
	@Column(name = "username")
	String name;
	
	@Column(nullable = false, length = 10) // 기본길이: 255
	String address;
	
	//enum 사용
	@Enumerated(EnumType.STRING)  // EnumType.ORDINAL(수치로 관리)
	RoleType roleType;
	
	@Transient
	String email;
	
	
	LocalDate createDate;        //카멜표기법
	LocalDate lastModifiedDate;  //카멜표기법
	
}





