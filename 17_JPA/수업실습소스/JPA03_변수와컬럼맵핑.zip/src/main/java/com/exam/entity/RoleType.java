package com.exam.entity;

public enum RoleType {
	USER, ADMIN
}
