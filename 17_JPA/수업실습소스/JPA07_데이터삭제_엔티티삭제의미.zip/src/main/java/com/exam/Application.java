package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		
		
		// 삭제작업:  유관순 조회
		Person x = em.find(Person.class, 1L);  // 엔티티 컨텍스트에 없기 때문에  select문 실행
		
		// 엔티티 삭제
		em.remove(x);    // 엔티티 컨텍스트에서 삭제

	
		log.info("LOGGER: commit 전");
		
		//트랜잭션 종료
		tx.commit();   // delete 문 실행
		
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







