package com.exam;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
	    // 엔티티에서 두개이상의 변수만 반환하는 경우
		// 1.6.2. Queries with multiple projected items 참조
		/*
		   id: 10001 이면 "one"
		   id: 10002 이면 "two"
		   id: 10003 이면 "three"
		   
		   //동등 case
		   case 컬럼 when 비교값 then 값
		            when 비교값 then 값
		            else 값
		   end
		   
		   //부등 case
		   case when 컬럼 > 비교값 then 값
		            when 컬럼 != 비교값 then 값
		            else 값
		   end
		*/
		String jpql = """   
				        select t.id as id,  t.description as desc,
				               case t.id when 10001L then 'ONE'
				                         when 10001L then 'TWO'
				                         else 'THREE'
				               end as mesg
				        from Todo as t
				   
				       """;
		

        // 1.  Tuple 이용
        List<Tuple> tuples =
                em.createQuery(jpql,Tuple.class)
                    .getResultList();
        for (Tuple tuple : tuples) {
        	Long id = tuple.get("id", Long.class);
            String description = tuple.get("desc", String.class);
            String mesg = tuple.get("mesg", String.class);
            log.info("LOGGER: 2. id와 description , mesg 출력:{}, {}, {}", id, description, mesg);
        }
	     
      
        
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







