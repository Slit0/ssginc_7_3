package com.exam.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@Builder
@Entity
public class Todo {

	@Id // pk 역할
	Long id;
	
	String description;

	LocalDateTime createdDate;
	
	LocalDateTime lastUpdatedDate;
	
	boolean done;
	
	
}
