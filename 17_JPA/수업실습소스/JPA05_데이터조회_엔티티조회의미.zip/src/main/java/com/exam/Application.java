package com.exam;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.exam.entity.Person;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
		//엔티티 조회
		Person p = em.find(Person.class, 1L); // 엔티티 컨텍스트에 없기 때문에 select문이 발생됨.
		log.info("1. 1L 조회:{}", p);
		
		Person p2 = em.find(Person.class, 1L); // 엔티티 컨텍스트에 있기 때문에 캐시로 처리
		log.info("2. 1L 조회:{}", p2);
		
		
		Person p3 = em.find(Person.class, 2L); // 엔티티 컨텍스트에 없기 때문에 select문이 발생됨.
		log.info("3. 2L 조회:{}", p3);
		
		//트랜잭션 종료
		tx.commit(); // insert 문 실행
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







