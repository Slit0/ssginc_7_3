package com.exam.service;

import java.util.List;

import com.exam.dto.TodoDTO;

public interface TodoService {

	//전체Todo 목록보기
	List<TodoDTO> findAll();
}
