package com.exam.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.TodoDTO;
import com.exam.service.TodoService;


@RestController
public class TodoController {

	TodoService todoService;

	public TodoController(TodoService todoService) {
		this.todoService = todoService;
	}
	
	@GetMapping("/todos")
	public ResponseEntity<List<TodoDTO>> findAll() {

		List<TodoDTO> todoDTOList = todoService.findAll();
		return ResponseEntity.status(200).body(todoDTOList);
	}
	
	
	
}
