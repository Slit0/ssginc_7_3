package com.exam.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.exam.dto.TodoDTO;
import com.exam.entity.Todo;
import com.exam.repository.TodoRepository;

@Service
public class TodoServiceImpl implements TodoService{

	TodoRepository todoRepository;
	
	public TodoServiceImpl(TodoRepository todoRepository) {
		this.todoRepository = todoRepository;
	}


	@Override
	public List<TodoDTO> findAll() {
		
		List<Todo> todoList = todoRepository.findAll();
		
		// List<Todo> ===> List<TodoDTO>
		
		List<TodoDTO> todoDTOList = todoList.stream().map(t->{   // t는 Todo
															   TodoDTO dto = TodoDTO.builder()
																	   	     .id(t.getId())
																	   	     .description(t.getDescription())
																	   	     .createdDate(t.getCreatedDate())
																	   	     .lastUpdatedDate(t.getLastUpdatedDate())
																	   	     .done(t.getDone())
																	   	     .build();
															   return dto;
	                                                  	}).collect(Collectors.toList()); 
		
		return todoDTOList;
	}

}



