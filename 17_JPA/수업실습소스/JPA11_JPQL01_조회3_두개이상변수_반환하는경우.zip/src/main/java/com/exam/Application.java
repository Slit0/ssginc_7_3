package com.exam;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Tuple;
import jakarta.persistence.TypedQuery;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Autowired
	EntityManagerFactory emf;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		EntityManager em = emf.createEntityManager();
		
		//트랜잭션 범위지정
		EntityTransaction tx = em.getTransaction();
		tx.begin(); // 트랜잭션 시작
		
	try {
		
	    // 엔티티에서 두개이상의 변수만 반환하는 경우
		// 1.6.2. Queries with multiple projected items 참조
		
		// 1.  Object[] 이용
		TypedQuery< Object[]> query =
				em.createQuery("select t.id,  t.description from Todo as t", Object[].class);
        List<Object[]> results = query.getResultList();
        for (var result : results) {
        	Long id = (Long) result[0];
		    String description = (String) result[1];
		    log.info("LOGGER: 1. id와 description 출력:{}, {}", id, description);
		}
        
        // 2.  Tuple 이용
        List<Tuple> tuples =
                em.createQuery("select t.id as id,  t.description as desc from Todo as t",
                                          Tuple.class)
                    .getResultList();
        for (Tuple tuple : tuples) {
        	Long id = tuple.get("id", Long.class);
            String description = tuple.get("desc", String.class);
            log.info("LOGGER: 2. id와 description 출력:{}, {}", id, description);
        }
	     
        //3. Map 이용
        List<Map> mapLst =
                em.createQuery("select t.id as id,  t.description as desc from Todo as t", Map.class)
                    .getResultList();
        for (Map map : mapLst) {
        	Long id = (Long) map.get("id");
            String description = (String) map.get("desc");
            log.info("LOGGER: 3. id와 description 출력:{}, {}", id, description);
        }
        
	}catch(Exception e) {
		e.printStackTrace();
		tx.rollback();		
	}finally {
		em.close();
	}
		
		
	}//end run
}//end class







