package com.exam.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.MemberDTO;
import com.exam.service.MemberService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MemberController {

	MemberService service;
	public MemberController(MemberService service) {
		this.service = service;
	}

	//회원가입
	/*
	    Talend API 에서 다음과 같이 JSON 요청하자.
	    POST 요청
	    header값: Content-type:application/json
	     {
	        "userid":"kim4832",
	        "passwd":"1234",
	        "username":"김유신"
	      }
	     위 JSON을 자바의 MemberDTO 에 저장됨. 
	 */
	 @PostMapping("/signup")
	 public ResponseEntity<MemberDTO> save(@Valid  @RequestBody MemberDTO dto) {
		 log.info("비번 암호화전: {}", dto.getPasswd());
		 //비번을 암호화 해야됨.
		 String encodedPW = new BCryptPasswordEncoder().encode(dto.getPasswd());
		 log.info("비번 암호화후: {}", encodedPW);
		 
		 dto.setPasswd(encodedPW);
		 int n = service.save(dto);
		 
		 return ResponseEntity.created(null).build();  // 201 상태코드 반환됨.
	 }
	 
	 //로그인 이후(인증후)의 요청가능
	 @GetMapping("/mypage")
	 public void mypage() {
		 
		 
	 }
	 
	 
}



