package com.exam.controller;

import java.net.URI;
import java.util.List;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.exam.dto.UserDTO;
import com.exam.service.UserService;

import lombok.extern.slf4j.Slf4j;

@RestController  // @Controller + @ResponseBody
@Slf4j
public class UserController {

	UserService service;
	
	public UserController(UserService service) {
		this.service = service;
	}

	//POST ( 저장 )
	/*
	    추가로 실제 저장할 데이터 지정: { "id":40, "username":"강감찬", birthdate:"2025-12-21"}
		추가로 header 정보 설정:  Content-type: application/json
		
		저장이 성공하면 200 반환됨.  ==> 나중에 201 ( created 상태값 ) 로 변경할 예정임.
	 */

	@PostMapping("/rest/users1")
	public void save(@RequestBody UserDTO dto) {
		int n = service.save(dto);
	}
	
	// POST 요청에 대한 응답처리 개선1 - 201 status code설정
	@PostMapping("/rest/users2")
	public ResponseEntity<UserDTO> save2(@RequestBody UserDTO dto) {
		//int n = service.save(dto);
		ResponseEntity<UserDTO> entity = ResponseEntity.created(null).build(); // 201 상태코드 
//		entity = ResponseEntity.badRequest().build();   // 400 상태코드
//		entity = ResponseEntity.notFound().build();   // 400 상태코드
//		entity = ResponseEntity.noContent().build();   // 204 상태코드
//		entity = ResponseEntity.internalServerError().build();   // 500 상태코드
		// 메서드가 제공되지 않는 경우는 status(상태값) 이용
//		entity = ResponseEntity.status(401).build();   // 401 상태코드
		return entity;
	}
	
	@PostMapping("/rest/users")
	public ResponseEntity<UserDTO> save3(@RequestBody UserDTO dto) {
		int n = service.save(dto);
		
		// http://localhost:8090/app/rest/users/60
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()  // http://localhost:8090/app/rest/users/
												  .path("/{id}")
												  .buildAndExpand(dto.getId())
												  .toUri();
		
		ResponseEntity<UserDTO> entity = ResponseEntity.created(location).build(); // 201 상태코드 와  location 추가

		return entity;
	}
	
	
	
	
	
	
	//  GET  http://localhost:8090/app/rest/users
	@GetMapping("/rest/users")
	public List<UserDTO> findAll(){
		return service.findAll();
	}

	
	
	
	// GET  http://localhost:8090/app/rest/users/10
	//  존재하지 않는 값 요청시 404 에러가 아닌 200 반환됨. ==>  나중에 404로 변경할 예정임.
	
	// 1. 일반적인 요청에 대한 응답처리
	@GetMapping("/rest/users2/{id}")
	public UserDTO findById2(@PathVariable Long id) {
		return service.findById(id);
	}
	
	//2. HATEOAS 설정
	@GetMapping("/rest/users/{id}")
	public EntityModel<UserDTO> findById(@PathVariable Long id) {
		
		UserDTO dto  =service.findById(id);
		
		// 요청에 해당되는 UserDTO 저장 역할
		EntityModel<UserDTO> entityModel = EntityModel.of(dto);
		
		// 추가링크 설정
		// 전체 사용자 조회
		WebMvcLinkBuilder link1 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(this.getClass()).findAll());
		
		// 요청한 id 다음 사용자 조회
		WebMvcLinkBuilder link2 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(this.getClass()).findById(id+10));
		
		// 요청한 id 이전 사용자 조회
		WebMvcLinkBuilder link3 = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(this.getClass()).findById(id-10));
		
		
		// 생성된 링크를 최종적으로 EntityModel 저장
		entityModel.add(link1.withRel("findAll"));  // 저장된 링크에 대한 key값 설정
		entityModel.add(link2.withRel("next_user"));  // 저장된 링크에 대한 key값 설정
		entityModel.add(link3.withRel("prev_user"));  // 저장된 링크에 대한 key값 설정
		
		return entityModel;
	}

	

	// PUT ( 수정 )
	/*
	   where 절에 필요한 id는 PathVariable로 전달하고
	   수정할 데이터인 username 과 birthdate 는 {"username":"강감찬2", birthdate:"2025-12-21"} 전달한다.
	   추가로 header 정보 설정:  Content-type: application/json
	*/
	@PutMapping("/rest/users/{id}")
	public void update(@PathVariable Long id, @RequestBody UserDTO dto) {
		dto.setId(id);
		int n = service.update(dto);
	}
	
	// DELETE ( 삭제 )
	@DeleteMapping("/rest/users/{id}")
	public void delete(@PathVariable Long id) {
		int n = service.delete(id);
	}
}










