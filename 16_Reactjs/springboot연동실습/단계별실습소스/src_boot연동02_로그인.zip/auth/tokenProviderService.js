export function getAuthToken() {
  const token = localStorage.getItem('jwtAuthToken');
  const userid = localStorage.getItem('userid');
  return { token: token, userid: userid };
}

// root에서 사용된 loader 함수임
export function tokenProviderLoader() {
  return getAuthToken();
}