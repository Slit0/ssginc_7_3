package com.exam.mapper;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.exam.dto.MemberDTO;

@Mapper
public interface MemberMapper {

	// 회원가입
	public int save(MemberDTO dto);
	
	// 로그인
	public MemberDTO authenticate(Map<String, String> map);
	
	// mypage
	public MemberDTO findById(String userid);
	
}
