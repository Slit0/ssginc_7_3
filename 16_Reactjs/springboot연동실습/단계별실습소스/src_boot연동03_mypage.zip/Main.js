
import { createBrowserRouter, RouterProvider, Navigate, useRouteLoaderData, redirect } from "react-router-dom";
import Home from "./pages/Home";
import Signup, { action as signUpAction } from "./pages/Signup";
import RootLayout from "./pages/RootLayout";
 import Login, { action as authAction } from "./pages/Login";
 import { tokenProviderLoader } from './auth/tokenProviderService';
 import MyPage, { loader as mypageLoader } from "./pages/MyPage";
 
const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    id: 'root',
    // 로그인 성공후 localStorage에 저장된 token과 userid를 가져와서 로드함.
    // 사용할때는 useRouteLoaderData('root') 이용해서 참조함.
    // 실제로 MenuNavigation.js 에서 사용함.
    loader: tokenProviderLoader, 
    children: [
      {
        path: '/',
        element: <Home />
      },
      {
        path: '/signup',        // 회원가입
        element: <Signup />,
        action: signUpAction
      },
      {
        path: '/login',         // 로그인
        element: <Login />,
        action: authAction
      },
      {
        path: '/logout',        // 로그아웃
        action: async function action() {
          localStorage.clear()
          // localStorage.removeItem('jwtAuthToken');
          // localStorage.removeItem('userid');
          return redirect('/');
        }
      },
      {
        path: '/mypage',       // 마이페이지
        element: <MyPage />,
        loader: mypageLoader
      },
    ]
  }
]);

function Main() {
  return <RouterProvider router={router} />
}

export default Main;
