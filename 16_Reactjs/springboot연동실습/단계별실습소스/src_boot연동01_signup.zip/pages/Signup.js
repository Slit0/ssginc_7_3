
import './Signup.css';
import {
  Form,
  redirect,
  useActionData
} from 'react-router-dom';

// import { fetchSignup } from '../api/httpMemberService';

function Signup() {

  return (
    <div className="container">
      <div className="signup">
        <div>
          <Form method="post" >
            <div>
              <label htmlFor="userid">userid:</label>
              <input type="text" name="userid" id="userid" />
            </div>
            <div>
              <label htmlFor="password">password:</label>
              <input type="password" name="passwd" id="password" defaultValue={1234} />

            </div>
            <div>
              <label htmlFor="username">username:</label>
              <input type="text" name="username" id="username" />
            </div>
            <div>
              <button name="signup" className="btn btn-success m-5" >signup</button>
            </div>
          </Form>
        </div>
      </div>
    </div>
  );
}

export async function action({ request }) {

  // 실제 boot 서버와 연동:  api/httpMemberService.js 의
  // fetchSignup() 함수와 연동
 
  return redirect('/');
}//end action

export default Signup;
