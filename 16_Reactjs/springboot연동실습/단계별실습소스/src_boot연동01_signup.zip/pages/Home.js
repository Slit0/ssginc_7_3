
import './Home.css';


function Home() {
	return (
		<div className="container">
			<div className="back-image">

			</div>
		</div>
	);
}

export default Home;
