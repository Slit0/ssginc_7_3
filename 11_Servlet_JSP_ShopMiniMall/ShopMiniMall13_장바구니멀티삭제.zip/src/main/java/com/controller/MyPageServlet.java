package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.dao.MemberDAO;
import com.dto.MemberDTO;
import com.service.MemberService;
import com.service.MemberServiceImpl;

// /mypage
public class MyPageServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//로그인한 사용자 정보를 DB에서 가져옴.
		MemberService service = new MemberServiceImpl();
		service.setDao(new  MemberDAO());
		
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String nextPage ="";
		if( dto != null) {
			// 세션이 있음
			String userid = dto.getUserid();
			
			MemberDTO mypageDTO = service.mypage(userid);
			session.setAttribute("login", mypageDTO);
			
			nextPage="mypage.jsp";
		}else {
			// 세션이 없음
			nextPage="member/loginInvalidate.jsp";
		}
		
		request.getRequestDispatcher(nextPage).forward(request, response);
		
	    
	}

}
