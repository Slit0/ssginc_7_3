package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import com.dao.CartDAO;
import com.dao.MemberDAO;
import com.dto.CartDTO;
import com.dto.MemberDTO;
import com.service.CartService;
import com.service.CartServiceImpl;
import com.service.MemberService;
import com.service.MemberServiceImpl;


// /cartList
public class CartListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		CartService service = new CartServiceImpl();
		service.setDao(new CartDAO());
		
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String nextPage ="";
		if( dto != null) {
			// 세션이 있음6
			
			String userid = dto.getUserid();
			List<CartDTO> cartList = service.cartList(userid);
			
			//scope 저장
			request.setAttribute("cartList", cartList);
			
			nextPage="cartList.jsp";
		}else {
			// 세션이 없음
			nextPage="member/loginInvalidate.jsp";
		}
		
		 request.getRequestDispatcher(nextPage).forward(request, response);
	    
	}//end doGet

}
