package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.dao.GoodsDAO;
import com.dto.GoodsDTO;
import com.service.GoodsService;
import com.service.GoodsServiceImpl;


public class MainServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
	
		GoodsService service = new GoodsServiceImpl();
		service.setDao(new GoodsDAO());
		
		// gCategory 해당하는 정보 얻기
		String gCategory = request.getParameter("gCategory");
		if(gCategory == null) gCategory = "top";
		
	    List<GoodsDTO> list = service.goodsList(gCategory);
		
	    //scope 저장
	    request.setAttribute("goodsList", list);
		
		request.getRequestDispatcher("main.jsp").forward(request, response);
	}

}
