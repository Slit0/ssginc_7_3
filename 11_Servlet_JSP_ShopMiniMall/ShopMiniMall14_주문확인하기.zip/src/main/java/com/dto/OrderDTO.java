package com.dto;

import java.time.LocalDate;
import java.util.List;

/*
 
   create table orderInfo
  (  num INT PRIMARY KEY AUTO_INCREMENT,
     userid VARCHAR(10),
     gCode varchar(20) not null,
     gSize CHAR(1) not null,
     gColor VARCHAR(10) not null,
     gAmount INT not null,
     
     orderName VARCHAR(10) NOT NULL,
     post VARCHAR(5) NOT NULL,
     addr1 VARCHAR(500) NOT NULL,
     addr2 VARCHAR(500) NOT NULL,
     phone VARCHAR(11) NOT NULL,
     orderDay DATE  DEFAULT (current_date)
  );   
 
 */

// 나중에 spring 에서는 lombok 라이브러리 이용

public class OrderDTO {
	
    int num;
    String userid;
    String gCode;
    String gSize;
    String gColor;
    int gAmount;
    String orderName;
    String post;
    String addr1;
    String addr2;
    String phone;
    LocalDate orderDay;
    
	public OrderDTO() {}

	public OrderDTO(int num, String userid, String gCode, String gSize, String gColor, int gAmount, String orderName,
			String post, String addr1, String addr2, String phone, LocalDate orderDay) {
		this.num = num;
		this.userid = userid;
		this.gCode = gCode;
		this.gSize = gSize;
		this.gColor = gColor;
		this.gAmount = gAmount;
		this.orderName = orderName;
		this.post = post;
		this.addr1 = addr1;
		this.addr2 = addr2;
		this.phone = phone;
		this.orderDay = orderDay;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getgCode() {
		return gCode;
	}

	public void setgCode(String gCode) {
		this.gCode = gCode;
	}

	public String getgSize() {
		return gSize;
	}

	public void setgSize(String gSize) {
		this.gSize = gSize;
	}

	public String getgColor() {
		return gColor;
	}

	public void setgColor(String gColor) {
		this.gColor = gColor;
	}

	public int getgAmount() {
		return gAmount;
	}

	public void setgAmount(int gAmount) {
		this.gAmount = gAmount;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDate getOrderDay() {
		return orderDay;
	}

	public void setOrderDay(LocalDate orderDay) {
		this.orderDay = orderDay;
	}

	@Override
	public String toString() {
		return "OrderDTO [num=" + num + ", userid=" + userid + ", gCode=" + gCode + ", gSize=" + gSize + ", gColor="
				+ gColor + ", gAmount=" + gAmount + ", orderName=" + orderName + ", post=" + post + ", addr1=" + addr1
				+ ", addr2=" + addr2 + ", phone=" + phone + ", orderDay=" + orderDay + "]";
	}
   
}
