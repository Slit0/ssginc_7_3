package com.service;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.OrderDAO;
import com.dto.CartDTO;
import com.dto.MemberDTO;

public class OrderServiceImpl implements OrderService {

	OrderDAO dao;
	
	public void setDao(OrderDAO dao) {
		this.dao = dao;
	}
	
	@Override
	public CartDTO orderConfirm(int num) {
		CartDTO dto = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			dto = dao.orderConfirm(session, num);
		}finally {
			session.close();
		}
		return dto;
	}

	@Override
	public MemberDTO orderConfirmMember(String userid) {
		
		MemberDTO dto = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			dto = dao.orderConfirmMember(session, userid);
		}finally {
			session.close();
		}
		
		return dto;
	}

}

/*
SqlSession session = MySqlSessionFactory.getSession();
		try {
			
		}finally {
			session.close();
		}  
*/