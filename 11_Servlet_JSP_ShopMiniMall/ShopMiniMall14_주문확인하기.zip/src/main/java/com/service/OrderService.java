package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dao.CartDAO;
import com.dao.OrderDAO;
import com.dto.CartDTO;
import com.dto.MemberDTO;

public interface OrderService {
	
	public void setDao(OrderDAO dao);
	public CartDTO orderConfirm(int num);
	public MemberDTO orderConfirmMember(String userid);
}
