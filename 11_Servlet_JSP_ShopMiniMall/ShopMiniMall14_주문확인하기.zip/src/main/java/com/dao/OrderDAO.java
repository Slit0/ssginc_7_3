package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.CartDTO;
import com.dto.MemberDTO;

public class OrderDAO {

	public CartDTO orderConfirm(SqlSession session, int num) {
		CartDTO dto = session.selectOne("com.config.OrderMapper.orderConfirm", num);
		return dto;
	}
	
	public MemberDTO orderConfirmMember(SqlSession session, String userid) {
		MemberDTO dto = 
		session.selectOne("com.config.OrderMapper.orderConfirmMember", userid);
		return dto;
	}
}
