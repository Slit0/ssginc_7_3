package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.dao.CartDAO;
import com.dao.MemberDAO;
import com.dto.CartDTO;
import com.dto.MemberDTO;
import com.service.CartService;
import com.service.CartServiceImpl;
import com.service.MemberService;
import com.service.MemberServiceImpl;


// /cartDeleteAll
public class CartDeleteAllServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		CartService service = new CartServiceImpl();
		service.setDao(new CartDAO());
		
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String nextPage ="";
		if( dto != null) {
		
			//체크된 값 조회
			String [] chk_arr = request.getParameterValues("check");			
			List<String> del_list = Arrays.asList(chk_arr);
			System.out.println(del_list);
			
			int n = service.cartDeleteAll(del_list);
			
			nextPage="cartList";  // CartListServlet
		}else {
			// 세션이 없음
			nextPage="member/loginInvalidate.jsp";
		}
		
		response.sendRedirect(nextPage);
	    
	}//end doGet

}
