package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.HashMap;

import com.dao.GoodsDAO;
import com.dao.MemberDAO;
import com.dto.GoodsDTO;
import com.dto.MemberDTO;
import com.service.GoodsService;
import com.service.GoodsServiceImpl;
import com.service.MemberService;
import com.service.MemberServiceImpl;


// /goodsRetrieve
public class GoodsRetrieveServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		GoodsService service = new GoodsServiceImpl();
		service.setDao(new GoodsDAO());
		
	    String gCode = request.getParameter("gCode");
	    
	    GoodsDTO dto = service.goodsRetrieve(gCode);
	    
	    //scope에 저장
	    request.setAttribute("goodsRetrieve", dto);
	    
	    // 요청위임
		request.getRequestDispatcher("goodsRetrieve.jsp").forward(request, response);
	}

}
