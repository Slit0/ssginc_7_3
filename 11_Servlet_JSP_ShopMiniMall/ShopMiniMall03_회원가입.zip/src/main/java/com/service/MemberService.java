package com.service;

import org.apache.ibatis.session.SqlSession;

import com.dao.MemberDAO;
import com.dto.MemberDTO;

public interface MemberService {

	public void setDao(MemberDAO dao);
	public MemberDTO idCheck(String userid);
	public int memberAdd(MemberDTO dto);
	
}
