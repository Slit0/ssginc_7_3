package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


public class MemberAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*
		    userid=aaa&
		    passwd=1&
		    passwd2=1&
		    username=홍길동&
		    post=51619&
		    addr1=경남+창원시+진해구+신항6로+101+%28남문동%29&
		    addr2=경남+창원시+진해구+남문동+1190-3&
		    phone1=010&
		    phone2=1234&
		    phone3=1234&
		    email1=aaa&
		    email2=daum.net&
		    email3=daum.net
	    
	    */
		
	}

}
