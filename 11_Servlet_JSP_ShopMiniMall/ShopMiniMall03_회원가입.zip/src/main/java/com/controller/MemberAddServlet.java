package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.dao.MemberDAO;
import com.dto.MemberDTO;
import com.service.MemberService;
import com.service.MemberServiceImpl;


public class MemberAddServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*
		    userid=aaa&
		    passwd=1&
		    username=홍길동&
		    post=51619&
		    addr1=경남+창원시+진해구+신항6로+101+%28남문동%29&
		    addr2=경남+창원시+진해구+남문동+1190-3&
		    phone1=010&
		    phone2=1234&
		    phone3=1234&
		    email1=aaa&
		    email2=daum.net&
		
	    */
		MemberService service = new MemberServiceImpl();
		service.setDao(new  MemberDAO());
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		String username = request.getParameter("username");
		String post = request.getParameter("post");
		String addr1 = request.getParameter("addr1");
		String addr2 = request.getParameter("addr2");
		String phone1 = request.getParameter("phone1");
		String phone2 = request.getParameter("phone2");
		String phone3 = request.getParameter("phone3");
		String email1 = request.getParameter("email1");
		String email2 = request.getParameter("email2");
		
		MemberDTO dto = 
				new MemberDTO(userid, passwd, username, post, addr1, addr2, phone1, phone2, phone3, email1, email2);
		
		
		int n = service.memberAdd(dto);
		
		//요청위임
		response.sendRedirect("main");
		
	}

}
