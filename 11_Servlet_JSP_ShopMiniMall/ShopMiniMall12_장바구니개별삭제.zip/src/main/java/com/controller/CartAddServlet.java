package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.HashMap;

import com.dao.CartDAO;
import com.dao.MemberDAO;
import com.dto.CartDTO;
import com.dto.MemberDTO;
import com.service.CartService;
import com.service.CartServiceImpl;
import com.service.MemberService;
import com.service.MemberServiceImpl;


// /cartAdd
public class CartAddServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	   // goodsRetreive.jsp에서 전달된 파라미터 얻고 최종적으로 CartDTO에 저장하기
	/*
	     userid <== 세션에서 얻기
		gCode=T10&
		gSize=L&
		gColor=white&
		gAmount=2
		
	*/
		
		CartService service = new CartServiceImpl();
		service.setDao(new CartDAO());
		
		HttpSession session = request.getSession();
		MemberDTO dto = (MemberDTO)session.getAttribute("login");
		String nextPage ="";
		if( dto != null) {
			// 세션이 있음6
			String userid = dto.getUserid();
			String gCode = request.getParameter("gCode");
			String gSize = request.getParameter("gSize");
			String gColor = request.getParameter("gColor");
			String gAmount = request.getParameter("gAmount");
			
			CartDTO cartDTO = new CartDTO();
			cartDTO.setUserid(userid);
			cartDTO.setgCode(gCode);
			cartDTO.setgSize(gSize);
			cartDTO.setgColor(gColor);
			cartDTO.setgAmount(Integer.parseInt(gAmount));
			
			int n = service.cartAdd(cartDTO);
			
			nextPage="goods/cartAddSuccess.jsp";
		}else {
			// 세션이 없음
			nextPage="member/loginInvalidate.jsp";
		}
		
		response.sendRedirect(nextPage);
	    
	}//end doGet

}
