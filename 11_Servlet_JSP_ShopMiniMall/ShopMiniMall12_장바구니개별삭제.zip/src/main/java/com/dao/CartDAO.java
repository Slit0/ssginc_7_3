package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.CartDTO;

public class CartDAO {

	public int cartAdd(SqlSession session, CartDTO dto) {
		int n = session.insert("com.config.CartMapper.cartAdd", dto);
		return n;
	}
	
	public List<CartDTO> cartList(SqlSession session, String userid) {
		List<CartDTO> list = session.selectList("com.config.CartMapper.cartList", userid);
		return list;
	}
	
	public int cartDelete(SqlSession session, int num) {
		int n = session.delete("com.config.CartMapper.cartDelete", num);
		return n;
	}
}
