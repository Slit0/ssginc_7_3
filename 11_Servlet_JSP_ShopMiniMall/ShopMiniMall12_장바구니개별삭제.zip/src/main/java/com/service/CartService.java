package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dao.CartDAO;
import com.dto.CartDTO;

public interface CartService {
	
	public void setDao(CartDAO dao);
	public int cartAdd( CartDTO dto);
	public List<CartDTO> cartList(String userid);
	public int cartDelete(int num);
}
