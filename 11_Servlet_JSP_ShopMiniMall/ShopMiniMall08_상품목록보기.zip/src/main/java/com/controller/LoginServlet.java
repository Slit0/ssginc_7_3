package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.HashMap;

import com.dao.MemberDAO;
import com.dto.MemberDTO;
import com.service.MemberService;
import com.service.MemberServiceImpl;


// /login
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		MemberService service = new MemberServiceImpl();
		service.setDao(new  MemberDAO());
		
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("userid", userid);
		map.put("passwd", passwd);
		
		MemberDTO dto = service.login(map);
		String nextPage ="";
		if(dto!=null) {
			//정상 로그인
			// 세션에 DTO 저장해서 로그인 여부 확인할 예정임.
			HttpSession session = request.getSession();
			session.setAttribute("login", dto);
			
			nextPage="main";
		}else {
			// id 또는 pw 틀림, 로그인 실패
			
			
			nextPage="member/loginFail.jsp";
		}
		
		response.sendRedirect(nextPage);
	    
	}

}
