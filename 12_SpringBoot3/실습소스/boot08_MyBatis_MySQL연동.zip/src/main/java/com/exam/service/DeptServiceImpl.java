package com.exam.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exam.dao.DeptDAO;
import com.exam.dto.DeptDTO;

@Service("deptService")
public class DeptServiceImpl implements DeptService {

	DeptDAO dao;

	public DeptServiceImpl(DeptDAO dao) {
		this.dao = dao;
	}

	@Override
	public List<DeptDTO> findAll() {
		return dao.findAll();
	}

	@Override
	@Transactional  // dao의 save 메서드가 실행되어 성공하면 자동으로 commit 됨. 생략 가능
	public int save(DeptDTO dto) {
		int n = dao.save(dto);
		return n;
	}

	@Override
	@Transactional // dao의 update 메서드가 실행되어 성공하면 자동으로 commit 됨. 생략 가능
	public int update(DeptDTO dto) {
		int n = dao.update(dto);
		return n;
	}
	
	
	
	
	
	
}
