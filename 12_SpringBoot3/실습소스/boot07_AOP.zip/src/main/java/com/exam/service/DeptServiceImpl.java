package com.exam.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service("deptService")
public class DeptServiceImpl implements DeptService{

	@Override
	public String sayEcho() {
		return "안녕하세요";
	}

	@Override
	public List<String> list() {
		return Arrays.asList("홍길동","이순신");
	}

}
