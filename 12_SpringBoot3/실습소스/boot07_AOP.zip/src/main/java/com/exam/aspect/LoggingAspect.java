package com.exam.aspect;

//부가기능 구현 클래스

public class LoggingAspect {

	public void loggingPrint() {
		
	}
	
}
