package com.exam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.exam.dto.MemberDTO;
import com.exam.service.MemberService;

@Controller
public class MemberController {

	
	MemberService memberService;
	
	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}

	//회원가입 화면보기
	@GetMapping("/signup")
	public String signupForm() {
		return "memberForm";
	}
	
	//id 중복체크
	@GetMapping("/idCheck")
	@ResponseBody
	public String idCheck(@RequestParam String userid) {
		
		String mesg = "아이디 사용 가능";
		
		MemberDTO dto = memberService.idCheck(userid);
		
		if(dto!=null) {
			mesg = "아이디 중복";
		}
		
		return mesg;
	}
	
	
}
