package com.exam.service;

import com.exam.dto.MemberDTO;

public interface MemberService {

	public MemberDTO idCheck(String userid);
}
