package com.exam.controller;

import java.util.Enumeration;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class TestController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@GetMapping("/set")
	public String set(Map<String, String> m) {   // 내부적으로 객체생성됨.
	
		m.put("userid", "홍길동" );
		m.put("passwd", "1234" );
	
		return "main";
	}
	
	@GetMapping("/set2")
	public String set2(Model m) { // 내부적으로 객체생성됨.
	
		m.addAttribute("userid", "홍길동" );
		m.addAttribute("passwd", 1234 );
		
		return "main";
	}
	
	
	
	@GetMapping("/set1")
	public String set1(HttpServletRequest request) {
	
		request.setAttribute("userid", "홍길동" );
		request.setAttribute("passwd", 1234 );
		
		return "main";
	}
	
	

}






