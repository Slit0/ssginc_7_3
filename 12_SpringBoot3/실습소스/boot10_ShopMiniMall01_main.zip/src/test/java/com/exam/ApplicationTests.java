package com.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("DemoApplicationTests");
	}
	@Test
	void contextLoads1() {
		System.out.println("DemoApplicationTests");
	}
}
