package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.dao.BoardDAO;
import com.dto.BoardDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;

//   /retrieve
public class BoardRetrieveServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		BoardService service = new BoardServiceImpl();
	    service.setDao(new BoardDAO());
	    
		String num = request.getParameter("num");
		
		BoardDTO dto = service.retrieve(Integer.parseInt(num));

		//scope 저장
		request.setAttribute("retrieve", dto);
		
		//jsp에 요청위임
		request.getRequestDispatcher("retrieve.jsp").forward(request, response);
		
	}
}
