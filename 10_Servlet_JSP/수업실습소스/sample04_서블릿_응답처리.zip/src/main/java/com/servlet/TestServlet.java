package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/test")
public class TestServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		// 서버 콘솔에 출력
		System.out.println("TestServlet");  
		
		
		// 웹 브라우저에 출력 ( 응답처리 )
		response.setContentType("text/html");  // "text/html;charset=utf-8"
		
		PrintWriter out = response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		out.print("hello, 안녕하세요");
		out.print("</body>");
		out.print("</html>");
		
		
		
		
		
	}
}
