// test.js

console.log("test.js");