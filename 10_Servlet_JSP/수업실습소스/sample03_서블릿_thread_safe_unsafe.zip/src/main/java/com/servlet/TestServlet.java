package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/test")
public class TestServlet extends HttpServlet {

	// 인스턴스 변수 
	//( 서블릿은 단 한번만 생성되기 때문에 인스턴스 변수가 여러 사용자들간에 공유가 가능)
	// thread-unsafe 해짐
	int num = 10;
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		int size = 10; // 로컬변수이기 때문에 thread-safe 해짐.
		
		num++;
		size++;
		
		System.out.println("TestServlet 인스턴스변수:" + num );
		System.out.println("TestServlet 로컬변수:" + size );
	
	}
}
