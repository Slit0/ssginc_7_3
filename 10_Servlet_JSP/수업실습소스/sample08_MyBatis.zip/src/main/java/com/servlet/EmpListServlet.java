package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.dao.EmpDAO;
import com.dto.EmpDTO;
import com.service.EmpService;
import com.service.EmpServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class EmpListServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		EmpService service = new EmpServiceImpl();
		service.setDao(new EmpDAO());
		List<EmpDTO> list = service.findAll();
		
		// 응답처리
        response.setContentType("text/html");  // "text/html;charset=utf-8"
		
		PrintWriter out = response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		
		out.print("<html><body>");
		out.print("<table border='1'>");
		out.print("<tr>");
		out.print("<th>사원번호</th>");
		out.print("<th>사원명</th>");
		out.print("<th>입사일</th>");
		out.print("<th>월급</th>");
		out.print("<th>부서번호</th>");
		out.print("</tr>");
		
		for (EmpDTO emp : list) {
			int empno = emp.getEmpno();
			String ename = emp.getUsername();
			String hiredate = emp.getHiredate();
			int sal = emp.getSalary();
			int deptno = emp.getDeptno();
			out.print("<tr>");
			out.print("<td>"+empno+"</td>");
			out.print("<td>"+ename+"</td>");
			out.print("<td>"+hiredate+"</td>");
			out.print("<td>"+sal+"</td>");
			out.print("<td>"+deptno+"</td>");
			out.print("</tr>");
		}
		out.print("</table>");
		out.print("</body></html>");
		out.print("</body>");
		out.print("</html>");
		
		
		 
	}	
}










