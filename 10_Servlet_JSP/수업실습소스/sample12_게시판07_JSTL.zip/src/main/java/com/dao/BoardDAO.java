package com.dao;

import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.dto.BoardDTO;
import com.dto.PageDTO;

public class BoardDAO {

	public PageDTO list(SqlSession session, int curPage){
		PageDTO pageDTO = new PageDTO();
		
		int start = (curPage - 1) * pageDTO.getPerPage();
		List<BoardDTO> list =
				session.selectList("com.config.BoardMapper.list",null, 
						new RowBounds(start, pageDTO.getPerPage()));
		
		int totalRecord = session.selectOne("com.config.BoardMapper.totalRecord");
		
		//PageDTO 값 저장
		pageDTO.setList(list);
		pageDTO.setCurPage(curPage);
		pageDTO.setTotalRecord(totalRecord);
		return pageDTO;
	}
	
	public int write(SqlSession session, BoardDTO dto ) {
		int num = session.insert("com.config.BoardMapper.write", dto);
		return num;
	}
	
	public BoardDTO retrieve(SqlSession session, int num) {
		BoardDTO dto = session.selectOne("com.config.BoardMapper.retrieve", num);
		return dto;
	}
	
	public int readcnt(SqlSession session, int num) {
		int n = session.update("com.config.BoardMapper.readcnt", num);
		return n;
	}
	
	public int update(SqlSession session,  BoardDTO dto) {
		int n = session.update("com.config.BoardMapper.update", dto);
		return n;
	}
	
	public int delete(SqlSession session, int num) {
		int n = session.delete("com.config.BoardMapper.delete", num);
		return n;
	}
}
