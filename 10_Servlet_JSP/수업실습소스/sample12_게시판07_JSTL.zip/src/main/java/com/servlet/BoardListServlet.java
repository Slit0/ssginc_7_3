package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import com.dao.BoardDAO;
import com.dto.BoardDTO;
import com.dto.PageDTO;
import com.service.BoardService;
import com.service.BoardServiceImpl;


public class BoardListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		BoardService service = new BoardServiceImpl();
	    service.setDao(new BoardDAO());
	
	    //현재페이지 번호
	    String curPage = request.getParameter("curPage");
	    if(curPage == null) curPage="1";
	    
	    PageDTO pageDTO = service.list(Integer.parseInt(curPage));
	    
	    // list 데이터를 scope에 저장
	    request.setAttribute("findAll", pageDTO);
	    
	    // jsp에게 요청위임
	    request.getRequestDispatcher("list.jsp").forward(request, response);
	}

}
