package com.service;

import com.dao.BoardDAO;
import com.dto.BoardDTO;
import com.dto.PageDTO;

public interface BoardService {
	public abstract void setDao(BoardDAO dao);
	public abstract PageDTO list(int curPage);
	public int write(BoardDTO dto );
	public BoardDTO retrieve(int num); 
	public int update(BoardDTO dto);
	public int delete(int num);
}
