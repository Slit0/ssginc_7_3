package com.filter;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import java.io.IOException;


public class MyFilter  implements Filter {
       
	public void destroy() {
		System.out.println("MyFilter.destroy");
	}

	public void doFilter(ServletRequest request, 
			ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
	
		//서블릿 요청전 코드 작업 ( 요청 필터 )
		System.out.println("MyFilter.요청 필터");
		
		chain.doFilter(request, response);
		
		//서블릿 응답후 코드 작업 ( 응답 필터 )
		System.out.println("MyFilter.응답 필터");
		
	}

	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("MyFilter.init");
	}

}
