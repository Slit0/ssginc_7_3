package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.BoardDAO;
import com.dto.BoardDTO;
import com.dto.PageDTO;

public class BoardServiceImpl implements BoardService {

	BoardDAO dao;
	
	@Override
	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}
	@Override
	public PageDTO list(int curPage) {
		PageDTO pageDTO = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			pageDTO = dao.list(session, curPage);
		}finally {
			session.close();
		}
		return pageDTO;
	}//end list
	@Override
	public int write(BoardDTO dto) {
		int num = 0;
		 SqlSession session = MySqlSessionFactory.getSession();
			try {
			  num = dao.write(session, dto);
			  session.commit();
			}finally {
				session.close();
			}
		return num;
	}
	
	@Override
	public BoardDTO retrieve(int num) {
		BoardDTO dto = null;
		 SqlSession session = MySqlSessionFactory.getSession();
			try {
				// num에 해당하는 조회수 증가
				int n = dao.readcnt(session, num);
				session.commit();
				dto = dao.retrieve(session, num);
			}finally {
				session.close();
			}
		return dto;
	}
	@Override
	public int update(BoardDTO dto) {
		int n= 0;
		  SqlSession session = MySqlSessionFactory.getSession();
			try {
			  n = dao.update(session, dto);
			  session.commit();
			}finally {
				session.close();
			}
		return n;
	}
	@Override
	public int delete(int num) {
		int n = 0;
		 SqlSession session = MySqlSessionFactory.getSession();
			try {
			n = dao.delete(session, num);
			session.commit();
			}finally {
				session.close();
			}
		return n;
	}

}

/*
      SqlSession session = MySqlSessionFactory.getSession();
		try {
		
		}finally {
			session.close();
		}


*/