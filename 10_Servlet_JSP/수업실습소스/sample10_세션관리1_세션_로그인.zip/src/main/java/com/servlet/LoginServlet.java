package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
	
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		
		//DB 연동해서 id와 pw 유효성 검사
		//실습에서 id와 pw 모두 유효하다고 가정
		if("asdf".equals(userid)) {
			HttpSession session = request.getSession();
			
			// time-out 지정
			//session.setMaxInactiveInterval(3600); // 1시간 
			
			System.out.println("id: " + session.getId());
			
			session.setAttribute("userid", userid);
			
			response.sendRedirect("loginSuccess.jsp");
		}else {
			//  id와 pw 유효안한 경우
			response.sendRedirect("error.jsp");
		}
	
		
	}//end doGEt
}
