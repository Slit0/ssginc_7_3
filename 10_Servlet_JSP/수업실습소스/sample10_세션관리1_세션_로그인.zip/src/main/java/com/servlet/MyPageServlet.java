package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/mypage")
public class MyPageServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
	   // 로그인시 사용된 userid 이용해서 회원정보를 DB에서 얻기
	   // 세션에서 userid 얻음.
	   HttpSession session = request.getSession();
	
	   // userid 값이 null 일수도 있음. 따라서 조건체크 필수
	   // 1. 로그인 안한 경우
	   // 2. 로그인했는데 time-out된 경우
	   String userid = (String)session.getAttribute("userid");
		
	   if(userid != null) {
		   // 세션이 존재하는 경우
		   // DB 연동해서 userid 에 해당되는 이름/주소/... 가져옴.
		   // 가져온 값을 loginInfo.jsp 에서 보여줄 예정임.
		   String name = "홍길동";
		   String addr = "부산시";
		   
		   request.setAttribute("username", name);
		   request.setAttribute("address", addr);
		   
		   //요청위임 ( loginInfo.jsp )
		   // request scope에 저장되었기 때문에 forward 만 가능하다.
		   request.getRequestDispatcher("loginInfo.jsp").forward(request, response);
		   
	   }else {
		   // 세션이 존재하지 않는 경우 ( 로그인 안한 경우 또는 로그인했는데 time-out된 경우)
		   response.sendRedirect("loginForm.jsp");
	   }
		
	}//end doGet	
}
