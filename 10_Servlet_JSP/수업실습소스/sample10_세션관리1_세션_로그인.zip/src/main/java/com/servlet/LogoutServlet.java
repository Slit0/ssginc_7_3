package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		  HttpSession session = request.getSession();
		  String userid = (String)session.getAttribute("userid");
		  if(userid != null) {
			   // 로그아웃 처리
			   session.invalidate();
			   response.sendRedirect("loginForm.jsp");			   
		  }else {
			  // 세션이 존재하지 않는 경우 ( 로그인 안한 경우 또는 로그인했는데 time-out된 경우)
			   response.sendRedirect("logoutFail.jsp");
		  }
	}	
}
