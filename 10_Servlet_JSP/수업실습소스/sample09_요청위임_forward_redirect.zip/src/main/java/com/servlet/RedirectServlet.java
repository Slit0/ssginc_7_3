package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/redirect")
public class RedirectServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		System.out.println("RedirectServlet");
		
		// scope에 데이터 저장
		// request에 100번지에 생성
		request.setAttribute("request", "request");
		
		HttpSession session = request.getSession();
		session.setAttribute("session", "session");
		
		ServletContext application = getServletContext();
		application.setAttribute("application", "application");
		
		
		
		//요청위임- redirect 방식
		response.sendRedirect("target.jsp");
		
	}	
}
