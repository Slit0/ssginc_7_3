package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dao.BoardDAO;
import com.dto.BoardDTO;

public interface BoardService {
	public abstract void setDao(BoardDAO dao);
	public abstract List<BoardDTO> list();
	public int write(BoardDTO dto );
	public BoardDTO retrieve(int num); 
	public int update(BoardDTO dto);
	public int delete(int num);
}
