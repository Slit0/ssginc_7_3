package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/set")
public class SetCookieServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
		
		// 쿠키 생성
		System.out.println("SetCookieServlet");
		
		Cookie c = new Cookie("userid", "asdf");
		
		c.setMaxAge(3600); // 기본값은 -1 , 웹 브라우저에 저장됨
		System.out.println("getMaxAge: "+ c.getMaxAge());
		response.addCookie(c);
		
		
		
	}	
}
