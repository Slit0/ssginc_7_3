package com.service;

import java.util.List;

import com.dao.BoardDAO;
import com.dto.BoardDTO;

public interface BoardService {
	public abstract void setDao(BoardDAO dao);
	public abstract List<BoardDTO> list();
}
