package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.BoardDAO;
import com.dto.BoardDTO;

public class BoardServiceImpl implements BoardService {

	BoardDAO dao;
	
	@Override
	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}
	@Override
	public List<BoardDTO> list() {
		List<BoardDTO> list = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			list = dao.list(session);
		}finally {
			session.close();
		}
		return list;
	}//end list

}

/*
      SqlSession session = MySqlSessionFactory.getSession();
		try {
		
		}finally {
			session.close();
		}


*/