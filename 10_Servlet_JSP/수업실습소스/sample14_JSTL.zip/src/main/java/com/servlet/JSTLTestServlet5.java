package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.dto.Person;

@WebServlet("/jstl5")
public class JSTLTestServlet5 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
	

		
		 request.getRequestDispatcher("jstl5.jsp").forward(request, response);
		 
		
	}	
}
