package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/jstl3")
public class JSTLTestServlet3 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
	
		 // scope에 저장
		
		 request.setAttribute("username", "홍길동");
		 request.setAttribute("age", 10);
		 
		
		 request.getRequestDispatcher("jstl3.jsp").forward(request, response);
		 
		 
		
	}	
}
