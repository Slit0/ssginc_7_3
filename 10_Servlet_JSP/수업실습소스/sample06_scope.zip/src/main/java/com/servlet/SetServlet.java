package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/set")
public class SetServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
			
		// scope에 저장
		
		//1. request scope에 저장 ( 요청~응답 )
		request.setAttribute("request", "request scope");
		
		//2. session scope에 저장 ( 요청한 웹브라우저 )
		HttpSession session = request.getSession();
		session.setAttribute("session", "session scope");
		
		//3. application scope에 저장 ( tomcat 컨테이너 )
		ServletContext application = getServletContext();
		application.setAttribute("application", "application scope");
		
		// 응답처리
		// 웹 브라우저에 출력 ( 응답처리 )
		response.setContentType("text/html");  // "text/html;charset=utf-8"
		PrintWriter out = response.getWriter();
		
		out.print("<html>");
		out.print("<body>");
		out.print("request scope값:" + request.getAttribute("request")+"<br>");
		out.print("session scope값:" + session.getAttribute("session")+"<br>");
		out.print("application scope값:" + application.getAttribute("application")+"<br>");
		out.print("</body>");
		out.print("</html>");
		
		
	}	
}
