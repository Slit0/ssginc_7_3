package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/get")
public class GetServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
			
		// scope 조회
		
		//1. request scope 참조
		String s = (String)request.getAttribute("request");
		
		//2. session scope 참조
		HttpSession session = request.getSession();
		String s2 = (String)session.getAttribute("session");
		
		//3. application scope 참조
		ServletContext application = getServletContext();
		String s3 = (String)application.getAttribute("application");
		
		// 응답처리
		// 웹 브라우저에 출력 ( 응답처리 )
		response.setContentType("text/html");  // "text/html;charset=utf-8"
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<body>");
		out.print("request scope값:" + s +"<br>");
		out.print("session scope값:" + s2 +"<br>");
		out.print("application scope값:" + s3+"<br>");
		out.print("</body>");
		out.print("</html>");
	}	
}
