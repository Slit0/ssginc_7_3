package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.dto.Person;

@WebServlet("/el4")
public class ELTest4Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
	
		
		 List<Person> list = 
				  Arrays.asList(new Person("홍길동", 20), 
						        new Person("이순신", 30) );
		
		 
		 request.setAttribute("xxx", list);
		
		 request.getRequestDispatcher("el4.jsp").forward(request, response);
		 
		 
		
	}	
}
