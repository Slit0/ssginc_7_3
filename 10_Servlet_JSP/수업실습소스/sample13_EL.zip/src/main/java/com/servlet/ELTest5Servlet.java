package com.servlet;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/el5")
public class ELTest5Servlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,
			     HttpServletResponse response) 
			throws ServletException, IOException {
	
		 // scope에 저장
		
		 request.setAttribute("xxx", "홍길동");
		 
		 
		 HttpSession session = request.getSession();
		 session.setAttribute("xxx", "이순신");
		 
		 
		 ServletContext application = getServletContext();
		 application.setAttribute("xxx", "유관순");
		 
		
		 request.getRequestDispatcher("el5.jsp").forward(request, response);
		 
		 
		
	}	
}
