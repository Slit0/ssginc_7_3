package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySqlSessionFactory;
import com.dao.BoardDAO;
import com.dto.BoardDTO;

public class BoardServiceImpl implements BoardService {

	BoardDAO dao;
	
	@Override
	public void setDao(BoardDAO dao) {
		this.dao = dao;
	}
	@Override
	public List<BoardDTO> list() {
		List<BoardDTO> list = null;
		SqlSession session = MySqlSessionFactory.getSession();
		try {
			list = dao.list(session);
		}finally {
			session.close();
		}
		return list;
	}//end list
	@Override
	public int write(BoardDTO dto) {
		int num = 0;
		 SqlSession session = MySqlSessionFactory.getSession();
			try {
			  num = dao.write(session, dto);
			  session.commit();
			}finally {
				session.close();
			}
		return num;
	}

}

/*
      SqlSession session = MySqlSessionFactory.getSession();
		try {
		
		}finally {
			session.close();
		}


*/