package com.exam.controller;

import org.springframework.ai.audio.transcription.AudioTranscriptionPrompt;
import org.springframework.ai.audio.transcription.AudioTranscriptionResponse;
import org.springframework.ai.openai.OpenAiAudioSpeechModel;
import org.springframework.ai.openai.OpenAiAudioSpeechOptions;
import org.springframework.ai.openai.OpenAiAudioTranscriptionModel;
import org.springframework.ai.openai.OpenAiAudioTranscriptionOptions;
import org.springframework.ai.openai.api.OpenAiAudioApi;
import org.springframework.ai.openai.audio.speech.SpeechPrompt;
import org.springframework.ai.openai.audio.speech.SpeechResponse;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AudioController {
	
	OpenAiAudioTranscriptionModel transcriptionModel;
	
	OpenAiAudioSpeechModel openAiAudioSpeechModel;
	
	public AudioController(OpenAiAudioTranscriptionModel transcriptionModel, OpenAiAudioSpeechModel openAiAudioSpeechModel) {
		this.transcriptionModel = transcriptionModel;
		this.openAiAudioSpeechModel = openAiAudioSpeechModel;
	}
	
	@GetMapping("/ai/audio-to-text")
	public String audioTranscription() {
		
	   //https://docs.spring.io/spring-ai/reference/1.0/api/audio/transcriptions/openai-transcriptions.html 소스코드 참조
		OpenAiAudioApi.TranscriptResponseFormat responseFormat = OpenAiAudioApi.TranscriptResponseFormat.TEXT; // JSON, SRT( '시간범위: 문장' 포맷 )

		OpenAiAudioTranscriptionOptions transcriptionOptions = OpenAiAudioTranscriptionOptions.builder()
		    .language("ko")
//		    .prompt("Ask not this, but ask that")
		    .temperature(0.5f)   // 다양성과 창의성을 조절하는 매개변수.  값이 높을수록 더 창의적임.
		    .responseFormat(responseFormat)
		    .build();
		
		AudioTranscriptionPrompt transcriptionRequest = new AudioTranscriptionPrompt(new ClassPathResource("/audio/안녕하세요좋은아침입니다.mp3"), transcriptionOptions);
		AudioTranscriptionResponse response = transcriptionModel.call(transcriptionRequest);
	
		
		return response.getResult().getOutput();
	}
	
	@GetMapping("/ai/text-to-audio")
	public ResponseEntity<Resource> generateAudio() {
	
		// https://docs.spring.io/spring-ai/reference/1.0/api/audio/speech/openai-speech.html#speech-options 소스코드 참조
	
		OpenAiAudioSpeechOptions speechOptions = OpenAiAudioSpeechOptions.builder()
			    .model("tts-1")
			    .voice(OpenAiAudioApi.SpeechRequest.Voice.ALLOY)  // 다양한 목소리 지원 ( alloy, echo, fable, onyx, nova, shimmer )
			    .responseFormat(OpenAiAudioApi.SpeechRequest.AudioResponseFormat.MP3) // opus, flac, wav, pcm
			    .speed(1.0f)
			    .build();

			SpeechPrompt speechPrompt = new SpeechPrompt("안녕하세요 아름다운 밤입니다.", speechOptions);
			SpeechResponse response = openAiAudioSpeechModel.call(speechPrompt);
			
			// 다운로드 처리
			byte[] responseAsBytes = response.getResult().getOutput();
			
			ByteArrayResource byteArrayResource = new ByteArrayResource(responseAsBytes);
		
			 return ResponseEntity.ok()
					.contentType(MediaType.APPLICATION_OCTET_STREAM)
					.contentLength(byteArrayResource.contentLength())
					.header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("sample.mp3").build().toString())
					.body(byteArrayResource);
				
	}

}
