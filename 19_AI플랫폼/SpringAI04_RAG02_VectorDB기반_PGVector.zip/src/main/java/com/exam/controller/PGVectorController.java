package com.exam.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.QuestionAnswerAdvisor;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PGVectorController {

	ChatClient chatClient;
	
	VectorStore vectorStore;

	public PGVectorController(ChatClient.Builder builder, VectorStore vectorStore) {
		this.chatClient = builder
//						  .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore, SearchRequest.builder().topK(3).build() ))    // 전역 RAG 적용
//						  .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore))    // 전역 RAG 적용
				          .build();
		this.vectorStore = vectorStore;
	}
	
	
	@GetMapping("/ai/rag")
	public String ragQuestion() {
		
		String q = "커피 효능에 관하여 간략하게 설명해줘";
		
		return chatClient.prompt()
						 .user(q)
				         .call()
				         .content();
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////
	String prompt  ="""

			    질문:
			    {input}
			
			    DOCUMENTS:
			    {documents}
			 
			""";
	
	@GetMapping("/ai/rag2")
	public String ragQuestion2() {
		
		String q = "커피 단점에 관하여 간략하게 설명해줘";
		
	     PromptTemplate template = new PromptTemplate(prompt);
	     
	     Map<String, Object> promptParams = new HashMap<>();
	     promptParams.put("input", q);
	     promptParams.put("documents", findSimilarData(q));
	    		 
	    
	    return chatClient
	    		.prompt(template.create(promptParams))
	    		.call()
	    		.content();
	}
	
   // https://docs.spring.io/spring-ai/reference/1.0/api/vectordbs/pgvector.html#_metadata_filtering 
	public String findSimilarData(String q) {
		
	  List<Document>  documents	= vectorStore.similaritySearch(SearchRequest.builder().query(q).topK(3).build());
	  
	  return documents.stream()
			  .map(document -> document.getFormattedContent())
			  .collect(Collectors.joining());
	}
}
