import axios from 'axios';


const instance = axios.create({
    baseURL: 'http://localhost:8090/app',
    timeout: 2000,
    headers: { "Content-Type": "text/plain", }
});

export async function fetchFeedbackList() {

    const response = await instance.get(`/ai/feedback`);

    console.log("response: ", response)

    if (!response === 200) {
        console.log("fetchUsersList.ERROR")
        throw new Error('fetchUserList 요청 예외');
    }

    var resData = response.data;
    return resData;
}

export async function fetchFeedbackSave(feedback) {


    const response = await instance.post("/ai/feedback", feedback);

    if (!response === 200) {
        throw new Error('Failed to insert user data.');
    }


    var resData = await response.data;
    console.log("resData:", resData)
    return resData;
}

