package com.exam.controller;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.converter.ListOutputConverter;
import org.springframework.ai.converter.MapOutputConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.ActorFilms;
import com.exam.dto.FootBallPlayer;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ChatController {

	
	ChatClient chatClient;  // Chat 모델에 있는 클라이언트임
	
	public ChatController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }


	// http://localhost:8090/app/ai/chat?q="자바개발자가 알아야될 스킬 알려줘"
	@GetMapping("/ai/chat")
	public String prompt(@RequestParam String q) {
		
		log.info("LOGGER1: 질문: {}", q);
		String response = chatClient.prompt(q).call().content();
		log.info("LOGGER: 응닶: {}", response);
	
		return response;
	}
	
	@GetMapping("/ai/chat2")
	public String prompt2(@RequestParam String q) {
			
			log.info("LOGGER2: 질문: {}", q);
			String response = chatClient
					                .prompt(q)
					                .call()
					                .chatResponse()
					                .getResult()
					                .getOutput()
					                .getText();
			
			 Set<Entry<String,Object>> entries =  chatClient
					                .prompt(q)
					                .call()
					                .chatResponse()
					                .getMetadata()
					                .entrySet();
			
			 for (Entry<String, Object> entry : entries) {
				 log.info("LOGGER2: Metadata Entry: key:{}, value:{}", entry.getKey(), entry.getValue());
			}
			 
			 /*
			    MetaData
			    
			     LOGGER: Entry: key:system-fingerprint, value:fp_06737a9306
				 LOGGER: Entry: key:created, value:1741069559
			 
			 */
			 
			 
			 
			 
			log.info("LOGGER2: 응닶: {}", response);
			return response;
	}
	

	
	
	
	// http://localhost:8090/app/ai/chat3?name="이순신 장군"
	@GetMapping("/ai/chat3")
	public String prompt3(@RequestParam String name) {
		
		String message = """
				    
				   {x} 의 업적에 대하여 표로 알려줘.
			
				""";
		
		PromptTemplate template = new PromptTemplate(message);
		Prompt prompt = template.create(Map.of("x", name));
		
//		return chatClient.prompt(prompt)
//				         .call()
//				         .chatResponse()
//			                .getResult()
//			                .getOutput()
//			                .getText();
		
		return chatClient.prompt(prompt)
		         .call()
		         .content();
	}
	
	
		// 프로프트 외부파일로 작성하기
		// http://localhost:8090/app/ai/chat4?name="유관순"
		@Value("classpath:/prompts/system-message.st")
		org.springframework.core.io.Resource systemResource;
		
		@GetMapping("/ai/chat4")
		public String prompt4(@RequestParam String name) {
			
		
//			SystemPromptTemplate template = new SystemPromptTemplate(systemResource);
			PromptTemplate template = new PromptTemplate(systemResource);
			
			Prompt prompt = template.create(Map.of("x", name));
			
//			return chatClient.prompt(prompt)
//					         .call()
//					         .chatResponse()
//				                .getResult()
//				                .getOutput()
//				                .getText();
		
			return chatClient.prompt(prompt)
			         .call()
			         .content();
		}
		
		// http://localhost:8090/app/ai/chat5?q="야구"
		// http://localhost:8090/app/ai/chat5?q=""   // 비워두거나 잘못된 값 지정 
		@GetMapping("/ai/chat5")
		public String prompt5(@RequestParam String q) {
			
			String systemText  = """
				    
					   축구 규칙에 대해서 알려줘.
				
					""";
			String systemText2  = """
				    
					   만일 요청된 스포츠에 관하여 잘 모르면 그냥 모른다고 응답해줘.
				
					""";
			
			String userText  = """
					    
					   %s 규칙에 대해서 알려줘.
				
					""";
			
		
			
			UserMessage userMessage = new UserMessage(String.format(userText, q));
			SystemMessage systemMessage = new SystemMessage(systemText);

			
			Prompt prompt = new Prompt(List.of(userMessage, systemMessage));
			
			return chatClient.prompt(prompt)
					         .call()
					         .chatResponse()
					         .getResult()
					         .getOutput()
					         .getText();
					         
		}
		
		// Converter 실습
		
		// 가. Converter 적용안된 경우
		// http://localhost:8090/app/ai/chat6?q="축구"
		@GetMapping("/ai/chat6")
		public String prompt6(@RequestParam String q) {
			
			String message = """
                        전 세계 {x} 선수에 대한 이름을 포함해서 경력 목록을 만들어줘.
					""";
	
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q));
		
			return chatClient.prompt(prompt)
			         .call()
			         .content();
			
			/*
				응답결과
				물론입니다! 아래는 전 세계 유명 축구 선수들과 그들의 경력 목록입니다.

			### 1. 리오넬 메시 (Lionel Messi)
			- **출생년도**: 1987년
			- **포지션**: 공격수
			- **경력**:
			  - FC 바르셀로나 (2004-2021)
			  - 파리 생제르맹 (2021-현재)
			  - 아르헨티나 국가대표 (2005-현재)
			  - 주요 수상: 발롱도르 수상 7회, FIFA 월드컵 우승 (2022)
			      
			 ...
			 
			*/
		}
		
		// 나. Converter 적용 된 경우
		// https://howtodoinjava.com/spring-ai/structured-output-converters/ 참조
		// http://localhost:8090/app/ai/chat7?q="축구"
		// 이것을 만들 때 적절한 프롬프트를 만드는 것은 항상 시행착오가 필요하다.
		
		@GetMapping("/ai/chat7")
		public List<FootBallPlayer> prompt7(@RequestParam String q) {
			
			
			//Converter
			BeanOutputConverter<List<FootBallPlayer>> converter = 
					new BeanOutputConverter<>(new ParameterizedTypeReference<List<FootBallPlayer>>() {});
			
			String message = """
					    
                        전 세계 {x} 선수에 대한 이름을 포함해서 경력 목록을 만들어줘.
                        ----------------------------------------------
                        ----------------------------------------------
					    {format}
					""";
			
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q, "format", converter.getFormat()));
			
			/*
			   converter.getFormat() 실제 구현 코드는 다음과 같다.
			   
			    	@Override
					public String getFormat() {
						String template = """
								Your response should be in JSON format.
								Do not include any explanations, only provide a RFC8259 compliant JSON response following this format without deviation.
								Do not include markdown code blocks in your response.
								Remove the ```json markdown from the output.
								Here is the JSON Schema instance your output must adhere to:
								```%s```
								""";
						return String.format(template, this.jsonSchema);
					}
			 */

			Generation result = chatClient.prompt(prompt)
											  .call()
											  .chatResponse()
											  .getResult();
			
			return  converter.convert(result.getOutput().getText());
			
			/*
			    응답 결과:
			    
			    [
					{
					"playerName": "이강인",
					"careerList":[
					"FC Barcelona Youth",
					"Valencia CF",
					"Paris Saint-Germain",
					"대한민국 U-20 국가대표",
					"대한민국 A대표팀"
					]
					},
			
			
			*/
		}
		
		
		
		@GetMapping("/ai/chat7-1")
		public List<List<String>> prompt7_1(@RequestParam String q) {
			
			
			//Converter
			BeanOutputConverter< List<List<String>>> converter = 
					new BeanOutputConverter<>(new ParameterizedTypeReference< List<List<String>>>() {});
			
			/*
			[
				[
				"손흥민",
				"토트넘 홋스퍼",
				"2015-현재",
				"프리미어리그",
				"FA컵",
				"EFL컵",
				"UEFA 챔피언스리그"
				],
				[
				"박지성",
				"맨체스터 유나이티드",
				"2005-2012",
				"프리미어리그",
				"FA컵",
				"UEFA 챔피언스리그",
				"FIFA 클럽 월드컵"
				],
				[
				"이강인",
				"발렌시아 CF",
				"2018-2021",
				"라리가",
				"코파 델 레이",
				"UEFA 유로파리그"
				],
				[
				"구자철",
				"아우크스부르크",
				"2016-2019",
				"분데스리가",
				"DFB-포칼"
				],
				[
				"황희찬",
				"RB 라이프치히",
				"2021-현재",
				"분데스리가",
				"DFB-포칼",
				"UEFA 챔피언스리그"
				]
			]
			
			*/
			String message = """
					    
                           전 세계 {x} 선수에 대한 이름을 포함해서 경력 목록을 만들어줘.
        
					    {format}
					""";
			
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q,"format", converter.getFormat()));
//			
//			List<String> response = chatClient.prompt(prompt)
//			         						  .call()
//			         						   .entity(new ParameterizedTypeReference<List<String>>() {});
			
			Generation result = chatClient.prompt(prompt)
											  .call()
											  .chatResponse()
											  .getResult();
			
			return  converter.convert(result.getOutput().getText());
		}
		
		record Player2(String playerName, List<String> careerList) {}
		
		@GetMapping("/ai/chat7-3")
		public List<String> prompt7_3(@RequestParam String q) {
			
			
			//Converter
			ListOutputConverter converter = 
					new ListOutputConverter(new DefaultConversionService());
			
			/*
			   결과 포맷은 다음과 같다.
				
			   [
					"리오넬 메시",
					"크리스티아누 호날두",
					"네이마르",
					"지네딘 지단",
					"펠레",
					"디에고 마라도나",
					"요한 크루이프",
					"미하엘 발락",
					"앤디 맥도널드",
					"프랭크 램파드"
				]
			
			*/
			String message = """
                         전 세계 {x} 선수에 대한 이름을 포함해서 경력 목록을 만들어줘.
                   
					    {format}
					""";
			
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q, "format", converter.getFormat()));
			Generation result = chatClient.prompt(prompt)
											  .call()
											  .chatResponse()
											  .getResult();
			
			return  converter.convert(result.getOutput().getText());
		}
		
		@GetMapping("/ai/chat7-4")
		public Map<String, Object> prompt7_4(@RequestParam String q) {
			
			
			//Converter
			MapOutputConverter converter = new MapOutputConverter();
			
			/*
			   결과 포맷은 다음과 같다.
			   
			   {
				"football": {
						"players": [
								{
								"name": "Lionel Messi",
								"nationality": "Argentinian",
								"position": "Forward",
								"clubs": [
									{
									"name": "FC Barcelona",
									"years": "2004-2021"
									},
									{
									"name": "Paris Saint-Germain",
									"years": "2021-present"
									}
								],
								"internationalCareer": {
										"nationalTeam": "Argentina",
										"years": "2005-present",
										"achievements": [
											"FIFA World Cup Champion (2022)",
											"Copa America Champion (2021)"
										]
								}
					},
			
			
			*/
			String message = """
					    
                         전 세계 {x} 선수에 대한 이름을 포함해서 경력 목록을 만들어줘.
                   
					    {format}
					""";
			
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q,"format", converter.getFormat()));
			
			Generation result = chatClient.prompt(prompt)
											  .call()
											  .chatResponse()
											  .getResult();
			
			return  converter.convert(result.getOutput().getText());
		}
		
		
		// entity 타입으로 반환
		//http://localhost:8090/app/ai/chat8?q="축구"
		@GetMapping("/ai/chat8")
		public List<String> prompt8(@RequestParam String q) {
			
			String message = """
					    
					   
                          전 세계 {x} 선수에 대해 이름 포함해서 경력 목록을 만들워줘.
				
					""";
			
			/*
				실행결과
				
				[
					"Lionel Messi - FC Barcelona (2004-2021), Paris Saint-Germain (2021-present)",
					"Cristiano Ronaldo - Sporting CP (2002-2003), Manchester United (2003-2009, 2021-present), Real Madrid (2009-2018), Juventus (2018-2021)",
					"Neymar Jr. - Santos FC (2009-2013), FC Barcelona (2013-2017), Paris Saint-Germain (2017-present)",
					"Kylian Mbappé - AS Monaco (2015-2017), Paris Saint-Germain (2017-present)",
					"Kevin De Bruyne - Chelsea FC (2012-2014), Werder Bremen (2012-2013, loan), VfL Wolfsburg (2014-2015), Manchester City (2015-present)",
					"Mohamed Salah - FC Basel (2012-2014), Chelsea FC (2014-2016), Fiorentina (2015, loan), Roma (2016-2017), Liverpool FC (2017-present)",
					"Robert Lewandowski - Lech Poznań (2006-2008), Borussia Dortmund (2008-2014), Bayern Munich (2014-2022), FC Barcelona (2022-present)",
					"Sadio Mané - Metz (2011-2012), Red Bull Salzburg (2012-2014), Southampton (2014-2016), Liverpool FC (2016-2022), Bayern Munich (2022-present)",
					"Virgil van Dijk - Groningen (2011-2013), Celtic (2013-2015), Southampton (2015-2018), Liverpool FC (2018-present)",
					"Karim Benzema - Lyon (2005-2009), Real Madrid (2009-present)"
				]
			
			
			*/
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q));
			
			List<String> response = chatClient.prompt(prompt)
			         						  .call()
			         						  .entity(new ParameterizedTypeReference<List<String>>() {});
			
			return  response;
		}
		
		
		// http://localhost:8090/app/ai/chat8-1?q="축구"
		@GetMapping("/ai/chat8-1")
		public List<FootBallPlayer> prompt8_1(@RequestParam String q) {
			
			String message = """
					    
					   
                         전 세계 {x} 선수에 대해 이름 포함해서 경력 목록을 만들워줘.
				
					""";
			
			/*
				실행결과
				
				[
					{
					"playerName": "Lionel Messi",
					"careerList":[
					"FC Barcelona (2004-2021)",
					"Paris Saint-Germain (2021-Present)",
					"Argentina National Team (2005-Present)"
					]
					},
			
			
			*/
			PromptTemplate template = new PromptTemplate(message);
			Prompt prompt = template.create(Map.of("x", q));
			
			List<FootBallPlayer> response = chatClient.prompt(prompt)
			         						  .call()
			         						   .entity(new ParameterizedTypeReference<List<FootBallPlayer>>() {});
			
			return  response;
		}
	
		
		// http://localhost:8090/app/ai/chat8-2?name="이병헌"
		@GetMapping("/ai/chat8-2")
		public ActorFilms prompt8_2(@RequestParam String q) {
			
			String message = """
				    
					   
                    배우 {x} 영화 출연작품과 년도  알려줘
			
				""";
		
		   /*	
			  {
				"actor": "이병헌",
				"movies": {
				"2000": "지금, 이 순간",
				"2001": "악마를 보았다",
				"2003": "멀고도 가까운",
				"2004": "내 머리 속의 지우개",
				"2006": "한반도",
				"2009": "우아한 세계",
				"2010": "하녀",
				"2015": "내부자들",
				"2016": "싱글라이더",
				"2019": "백두산",
				"2020": "남산의 부장들",
				"2021": "모가디슈",
				"2022": "드림"
				}
			  }	
			*/
		PromptTemplate template = new PromptTemplate(message);
		Prompt prompt = template.create(Map.of("x", q));
		
			ActorFilms actorFilms = chatClient.prompt(prompt)
				    .call()
				    .entity(ActorFilms.class);
			
			return actorFilms;
			
		}
		
		// http://localhost:8090/app/ai/chat8-3
		@GetMapping("/ai/chat8-3")
		public Map<String, String> prompt8_3() {
			
			
			/*
				실행결과
				
				   {
					"서울": "9740000",
					"부산": "3400000",
					"광주": "1500000",
					"대구": "2400000"
					}
								
			
			*/
			Map<String, String> cities = chatClient.prompt()
				    .user("서울 부산 광주 대구 인구 알려줘")
				    .call()
				    .entity(new ParameterizedTypeReference<Map<String, String>>() {});
			log.info("LOGGER: 응닶 cities: {}", cities);
			return cities;
			
		}
}