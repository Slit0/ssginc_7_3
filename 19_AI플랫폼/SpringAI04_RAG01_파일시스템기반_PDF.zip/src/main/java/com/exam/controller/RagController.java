package com.exam.controller;


import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.QuestionAnswerAdvisor;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RagController {

	ChatClient chatClient;
	
	VectorStore vectorStore;

	public RagController(ChatClient.Builder builder, VectorStore vectorStore) {
		this.chatClient = builder
//						  .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore, SearchRequest.builder().topK(3).build() ))    // 전역 RAG 적용
//						  .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore))    // 전역 RAG 적용
				          .build();
		this.vectorStore = vectorStore;
	}
	
	
	@GetMapping("/ai/rag")
	public String ragQuestion() {
		
		String q = "커피 효능에 관하여 간략하게 설명해줘";
		
		return chatClient.prompt()
						 .user(q)
				         .call()
				         .content();
		
		/*
	      커피는 여러 가지 건강 효능을 가지고 있습니다. 주요 효능은 다음과 같습니다:
		
		1. **각성 효과**: 커피에 포함된 카페인은 중추신경계를 자극하여 피로를 줄이고 집중력을 향상시킵니다.
		
		2. **신진대사 촉진**: 카페인은 지방 산화를 증가시키고 신진대사를 촉진하여 체중 관리에 도움을 줄 수 있습니다.
		
		3. **항산화 작용**: 커피는 항산화 물질이 풍부하여 세포 손상을 방지하고 만성 질환의 위험을 줄이는 데 기여합니다.
		
		4. **심혈관 건강**: 일부 연구에 따르면, 적당한 커피 소비는 심혈관 질환의 위험을 낮추는 것과 관련이 있을 수 있습니다.
		
		5. **기분 개선**: 커피는 기분을 좋게 하고 우울증 증상을 완화하는 데 도움이 될 수 있습니다.
		
		그러나 과도한 섭취는 불안, 수면 장애, 심장 두근거림 등의 부작용을 초래할 수 있으므로 적당히 섭취하는 것이 중요합니다.
	
	    */
	}
	
	@GetMapping("/ai/rag2")
	public String ragQuestion2() {
		
		String q = "커피 효능에 관하여 간략하게 설명해줘";
		
		
		return chatClient.prompt()
						 .advisors(new QuestionAnswerAdvisor(vectorStore, SearchRequest.builder().topK(3).build()))   // 개별적인 RAG 적용
//						 .advisors(new QuestionAnswerAdvisor(vectorStore))   // 개별적인 RAG 적용
						 .user(q)
				         .call()
				         .content();
		
		/*
		 coffee_vector_store.json 데이터 이용하여 답변 제공됨.
		 
		 커피는 여러 가지 효능을 가지고 있습니다. 주된 효능으로는 카페인이 중추신경을 자극하여 집중력과 기민성을 높이고,
		 혈압을 단기적으로 상승시킬 수 있으며, 알츠하이머 치매의 위험을 줄이는 데 도움이 될 수 있다는 연구 결과가 있습니다.
         또한, 커피를 하루에 3~5잔 마시면 자궁내막암과 전립선암의 위험을 줄일 수 있고, 항산화 성분이 풍부하여 노화 방지와 세포 산화 방지에 
         효과적입니다. 혈관의 탄력성을 개선하고 당뇨병의 위험을 줄이는 데도 긍정적인 영향을 미칠 수 있습니다.
	 
			
		*/	
	}
	
}
