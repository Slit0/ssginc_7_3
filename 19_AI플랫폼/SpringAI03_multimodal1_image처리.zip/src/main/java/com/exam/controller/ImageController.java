package com.exam.controller;

import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.model.Media;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ImageController {

	ChatModel chatModel;
	ImageModel imageModel;
	
	public ImageController(ChatModel chatModel, ImageModel imageModel) {
		this.chatModel = chatModel;
		this.imageModel = imageModel;
	}


	@GetMapping("/ai/image-to-text")
	public String describeImage() {
		
		// https://docs.spring.io/spring-ai/reference/1.0/api/multimodality.html 소스코드 참조
		
		var imageResource = new ClassPathResource("images/NewYork.jpg");

		var userMessage = new UserMessage(
			"이 그림에 대해서 설명해줘", // content
			new Media(MimeTypeUtils.IMAGE_JPEG, imageResource)); 
		
		ChatResponse response = chatModel.call(new Prompt(userMessage));
				          
		return response.getResult().getOutput().getText();
	}
	
	
	@GetMapping("/ai/text-to-image")
	public String generationImage() {
		
		// https://docs.spring.io/spring-ai/reference/1.0/api/image/openai-image.html#image-options 소스코드 참조
		// https://docs.spring.io/spring-ai/reference/1.0/api/image/openai-image.html#_configuration_properties
		// https://platform.openai.com/docs/api-reference/images/create   응답은 url로 반환
		ImageResponse response = imageModel.call(
		        new ImagePrompt("멋진 바다속에 있는 우주인",
		        OpenAiImageOptions.builder()
		                .withN(1)    // 이미지 갯수. 1 ~ 10 사이 지정,  DALL-E-3는 1개만 지원됨.  유료는 여러개 지정 가능.
		                .withHeight(1024)
		                .withWidth(1024)
		                .withQuality("hd")
		                .build()
		        		));
		
		return response.getResult().getOutput().getUrl();   // 응답은 url로 반환
	}

}
