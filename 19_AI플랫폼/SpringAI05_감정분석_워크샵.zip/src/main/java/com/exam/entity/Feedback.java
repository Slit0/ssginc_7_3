package com.exam.entity;


import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import com.exam.enumtype.SentimentType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
@Entity 
public class Feedback {

		@Id
		@GeneratedValue
		private Long id;
	
	    private String content;

	    private Double sentimentScore;

	    @CreationTimestamp
	    private LocalDateTime createdAt;

	    @Enumerated(EnumType.STRING)
	    private SentimentType sentiment;

}
