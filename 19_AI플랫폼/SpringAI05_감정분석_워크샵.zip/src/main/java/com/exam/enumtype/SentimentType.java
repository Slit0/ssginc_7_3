package com.exam.enumtype;

public enum SentimentType {
    POSITIVE,NEGATIVE,NEUTRAL
}
