package com.exam.service;

import java.util.List;

import com.exam.dto.FeedbackDTO;
import com.exam.entity.Feedback;

public interface FeedbackService {

	public List<FeedbackDTO> findAll();
	
	public FeedbackDTO analyzeFeedback(String content);
}
