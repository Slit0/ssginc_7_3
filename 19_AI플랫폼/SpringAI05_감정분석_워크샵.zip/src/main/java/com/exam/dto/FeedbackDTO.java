package com.exam.dto;


import java.time.LocalDateTime;

import com.exam.enumtype.SentimentType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@ToString
public class FeedbackDTO {

		private Long id;
	
	    private String content;

	    private Double sentimentScore;

	    private LocalDateTime createdAt;

	    private SentimentType sentiment;

	   
}
