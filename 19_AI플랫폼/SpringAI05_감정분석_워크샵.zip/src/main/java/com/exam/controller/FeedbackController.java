package com.exam.controller;


import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.FeedbackDTO;
import com.exam.service.FeedbackService;


@RestController
public class FeedbackController {

	
	FeedbackService service;
	
	public FeedbackController(FeedbackService service) {
		this.service = service;
	}


   @GetMapping("/ai/feedback")
    public List<FeedbackDTO> getAllFeedback() {
        return service.findAll();
    }

    @PostMapping("/ai/feedback")
    public FeedbackDTO saveFeedback(@RequestBody String content) {
    	return service.analyzeFeedback(content);
    }
	
}
