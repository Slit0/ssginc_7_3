package com.exam.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

@Component
public class AuthProvider implements AuthenticationProvider {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	// 사용자가 입력된 userid와 passwd 이용해서 DB 연동해서 체크
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		logger.info("LOGGER:AuthProvider.authenticate 호출");
		
		String userid = (String)authentication.getPrincipal();
		String passwd = (String)authentication.getCredentials();
		
		//DB 연동해서 체크
		
		
		return null;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return true;
	}

}
