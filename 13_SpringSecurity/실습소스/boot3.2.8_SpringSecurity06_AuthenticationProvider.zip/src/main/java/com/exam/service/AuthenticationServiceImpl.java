package com.exam.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.exam.dto.MemberDTO;

@Service
public class AuthenticationServiceImpl implements AuthenticationService{

	@Override
	public MemberDTO authenticate(Map<String, String> map) {
		return null;
	}
	
}
