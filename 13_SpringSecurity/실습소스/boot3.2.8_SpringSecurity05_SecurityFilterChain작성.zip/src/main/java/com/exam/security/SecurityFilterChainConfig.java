package com.exam.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.GetMapping;

@Configuration
public class SecurityFilterChainConfig {

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		
		//csrf 비활성화
		http.csrf((csrf) -> csrf.disable());
		
		//요청맵핑값 허용
		http.authorizeHttpRequests(auth->
		                           auth.requestMatchers("/home","/signup","/login").permitAll()  
		                              // .requestMatchers("/**").permitAll()
		                               .anyRequest()
		                               .authenticated()
				                  );
		
		//사용자 만든 로그인 정보 설정
		http.formLogin(formLogin->
		                  formLogin.loginPage("/login") //LoginController 의 @GetMapping(value={"/login"}) 값
				                   .loginProcessingUrl("/auth") // loginForm.jsp 의 <form action="auth"> 값
				                   .usernameParameter("userid") // loginForm.jsp 의 <input type="text" name="userid"  />
				                   .passwordParameter("passwd") // loginForm.jsp 의 <input type="password" name="passwd"  />
				                   .failureUrl("/login") //로그인 실패시 redirect 된 요청매핑값
				                   .defaultSuccessUrl("/home", true) //로그인 성공시 redirect 된 요청매핑값
				      );
		
		
		return http.build();
	}
	
}
