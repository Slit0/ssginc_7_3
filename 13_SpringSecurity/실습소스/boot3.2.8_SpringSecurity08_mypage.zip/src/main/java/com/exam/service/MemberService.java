package com.exam.service;

import com.exam.dto.MemberDTO;

public interface MemberService {
	public int save(MemberDTO dto);
	
}
